#!/bin/bash
#run the application

python FRONT_END/main.py
