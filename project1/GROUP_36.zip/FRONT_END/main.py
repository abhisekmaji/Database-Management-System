DB_HOST = "10.17.5.99"
DB_NAME = "group_36"
DB_USER = "group_36"
DB_PASS = "1Sv3VRj750NPC"
DB_PORT = "5432"

a_id = 999999
d_id = 999999
fr_id = 999999
f_id = 999999
i_id = 999999
ipo_id = 999999
m_id = 999999
o_id = 999999
of_id = 999999
p_id = 999999
r_id = 999999

from flask import Flask, render_template, request
import psycopg2
import psycopg2.extras


app = Flask(__name__)


@app.route("/")
def hello():
    return render_template('index.html')

@app.route("/admin")
def admin():
    return render_template('admin.html')

@app.route("/login")
def login():
    return render_template('login.html')

@app.route("/signup")
def signup():
    return render_template('signup.html')

@app.route("/adminq", methods = ['POST', 'GET'])
def adminq():
    if request.method == 'GET':
        return f"The URL /adminq is accessed directly. Try going to '/login' to login"
    elif request.method == 'POST':
        # conn = psycopg2.connect(dbname="startup_project", user="postgres", password="jatin", host="localhost", port="5432")
        conn = psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        cur.execute("select * from userdb where username = %s and password = %s", (request.form['Username'], request.form['Password']))
        result = cur.rowcount
        if result > 0:
            return render_template('adminq.html')
        else:
            return render_template('invalid.html')

@app.route("/adminq1", methods = ['POST', 'GET'])
def adminq1():
    if request.method == 'GET':
        return f"The URL /adminq1 is accessed directly. Try going to '/signup' to signup"
    elif request.method == 'POST':
        # conn = psycopg2.connect(dbname="startup_project", user="postgres", password="jatin", host="localhost", port="5432")
        conn = psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        try:
            cur.execute("insert into userdb(username, password) values (%s, %s)", (request.form['Username'], request.form['Password']))
            conn.commit()
            return render_template('adminq.html')
        except:
            conn.rollback()
            return render_template('invalid1.html')

@app.route("/query1")
def try1():
    return render_template('query1.html')

@app.route("/data", methods = ['POST', 'GET'])
def data():
    if request.method == 'GET':
        return f"The URL /data is accessed directly. Try going to '/query1' to submit form"
    # conn = psycopg2.connect(dbname="startup_project", user="postgres", password="jatin", host="localhost", port="5432")
    conn = psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if request.method == 'POST':
        if request.form['Entity Type'] == "Company":
            if request.form['Query Type'] == "Acquisitions":
                if request.form['Sort By'] == "Deal Amount Descending":
                    cur.execute("select objects1.name as \"Acquiring Company\", objects2.name as \"Acquired Company\", (case when f.price_amount = 0.0 then 'N/A' else cast(f.price_amount as text) end) as \"Deal Amount\", f.price_currency_code as \"Currency\", f.acquired_at as \"Deal Date\", f.source_url as \"News Source\" from objects as objects1, objects as objects2, (select acquiring_object_id, acquired_object_id, price_amount, price_currency_code, acquired_at, source_url from acquisitions where acquiring_object_id in (select id from objects where name = %s and entity_type = 'Company')) as f where f.acquiring_object_id = objects1.id and f.acquired_object_id = objects2.id order by f.price_amount desc limit %s;", (request.form['Entity Name'], request.form['Entries']))
                elif request.form['Sort By'] == "Deal Amount Ascending":
                    cur.execute("select objects1.name as \"Acquiring Company\", objects2.name as \"Acquired Company\", (case when f.price_amount = 0.0 then 'N/A' else cast(f.price_amount as text) end) as \"Deal Amount\", f.price_currency_code as \"Currency\", f.acquired_at as \"Deal Date\", f.source_url as \"News Source\" from objects as objects1, objects as objects2, (select acquiring_object_id, acquired_object_id, price_amount, price_currency_code, acquired_at, source_url from acquisitions where acquiring_object_id in (select id from objects where name = %s and entity_type = 'Company')) as f where f.acquiring_object_id = objects1.id and f.acquired_object_id = objects2.id order by f.price_amount asc limit %s;", (request.form['Entity Name'], request.form['Entries']))
                elif request.form['Sort By'] == "Least Recent Deal":
                    cur.execute("select objects1.name as \"Acquiring Company\", objects2.name as \"Acquired Company\", (case when f.price_amount = 0.0 then 'N/A' else cast(f.price_amount as text) end) as \"Deal Amount\", f.price_currency_code as \"Currency\", f.acquired_at as \"Deal Date\", f.source_url as \"News Source\" from objects as objects1, objects as objects2, (select acquiring_object_id, acquired_object_id, price_amount, price_currency_code, acquired_at, source_url from acquisitions where acquiring_object_id in (select id from objects where name = %s and entity_type = 'Company')) as f where f.acquiring_object_id = objects1.id and f.acquired_object_id = objects2.id order by f.acquired_at asc limit %s;", (request.form['Entity Name'], request.form['Entries']))
                else:
                    cur.execute("select objects1.name as \"Acquiring Company\", objects2.name as \"Acquired Company\", (case when f.price_amount = 0.0 then 'N/A' else cast(f.price_amount as text) end) as \"Deal Amount\", f.price_currency_code as \"Currency\", f.acquired_at as \"Deal Date\", f.source_url as \"News Source\" from objects as objects1, objects as objects2, (select acquiring_object_id, acquired_object_id, price_amount, price_currency_code, acquired_at, source_url from acquisitions where acquiring_object_id in (select id from objects where name = %s and entity_type = 'Company')) as f where f.acquiring_object_id = objects1.id and f.acquired_object_id = objects2.id order by f.acquired_at desc limit %s;", (request.form['Entity Name'], request.form['Entries']))
            elif request.form['Query Type'] == "IPO":
                cur.execute("select %s as \"Company\", valuation_amount as \"Company Valuation after IPO\", raised_amount as \"Amount Raised in IPO\", valuation_currecny_code as \"Currency\", public_at as \"IPO Debut\", stock_symbol as \"Stock Symbol\", source_url as \"News Source\" from ipos where object_id in (select id from objects where name = %s and entity_type = 'Company');", (request.form['Entity Name'], request.form['Entity Name']))
            elif request.form['Query Type'] == "Fundings":
                if request.form['Sort By'] == "Most Recent Funding":
                    cur.execute("select o.name as \"Company\", foo.funding_round_type as \"Funding Round\", foo.raised_amount_usd as \"Total Amount Raised (in USD)\", foo.source_url as \"News Source\", foo.invest as \"Investors\", foo.funded_at as \"Funding Date\" from objects as o, ( select f.*, foo.invest from funding_rounds as f, ( select funding_round_id, funded_object_id, array_agg(name) as invest from ( select i.funding_round_id, i.funded_object_id, o.name from investments as i, objects as o where i.funded_object_id in (select id from objects where name = %s and entity_type = 'Company') and i.investor_object_id = o.id) as foo group by funding_round_id, funded_object_id) as foo where f.funding_round_id = foo.funding_round_id and f.object_id = foo.funded_object_id) as foo where o.id = foo.object_id order by \"Funding Date\" desc limit %s;", (request.form['Entity Name'], request.form['Entries']))
                elif request.form['Sort By'] == "Least Recent Funding":
                    cur.execute("select o.name as \"Company\", foo.funding_round_type as \"Funding Round\", foo.raised_amount_usd as \"Total Amount Raised (in USD)\", foo.source_url as \"News Source\", foo.invest as \"Investors\", foo.funded_at as \"Funding Date\" from objects as o, ( select f.*, foo.invest from funding_rounds as f, ( select funding_round_id, funded_object_id, array_agg(name) as invest from ( select i.funding_round_id, i.funded_object_id, o.name from investments as i, objects as o where i.funded_object_id in (select id from objects where name = %s and entity_type = 'Company') and i.investor_object_id = o.id) as foo group by funding_round_id, funded_object_id) as foo where f.funding_round_id = foo.funding_round_id and f.object_id = foo.funded_object_id) as foo where o.id = foo.object_id order by \"Funding Date\" asc limit %s;", (request.form['Entity Name'], request.form['Entries']))
                elif request.form['Sort By'] == "Most Amount Raised in a Round":
                    cur.execute("select o.name as \"Company\", foo.funding_round_type as \"Funding Round\", foo.raised_amount_usd as \"Total Amount Raised (in USD)\", foo.source_url as \"News Source\", foo.invest as \"Investors\", foo.funded_at as \"Funding Date\" from objects as o, ( select f.*, foo.invest from funding_rounds as f, ( select funding_round_id, funded_object_id, array_agg(name) as invest from ( select i.funding_round_id, i.funded_object_id, o.name from investments as i, objects as o where i.funded_object_id in (select id from objects where name = %s and entity_type = 'Company') and i.investor_object_id = o.id) as foo group by funding_round_id, funded_object_id) as foo where f.funding_round_id = foo.funding_round_id and f.object_id = foo.funded_object_id) as foo where o.id = foo.object_id order by \"Total Raised Amount (in USD)\" desc limit %s;", (request.form['Entity Name'], request.form['Entries']))
                else:
                    cur.execute("select o.name as \"Company\", foo.funding_round_type as \"Funding Round\", foo.raised_amount_usd as \"Total Amount Raised (in USD)\", foo.source_url as \"News Source\", foo.invest as \"Investors\", foo.funded_at as \"Funding Date\" from objects as o, ( select f.*, foo.invest from funding_rounds as f, ( select funding_round_id, funded_object_id, array_agg(name) as invest from ( select i.funding_round_id, i.funded_object_id, o.name from investments as i, objects as o where i.funded_object_id in (select id from objects where name = %s and entity_type = 'Company') and i.investor_object_id = o.id) as foo group by funding_round_id, funded_object_id) as foo where f.funding_round_id = foo.funding_round_id and f.object_id = foo.funded_object_id) as foo where o.id = foo.object_id order by \"Total Raised Amount (in USD)\" asc limit %s;", (request.form['Entity Name'], request.form['Entries']))
            elif request.form['Query Type'] == "Milestones":
                if request.form['Sort By'] == "Most Recent":
                    cur.execute("select %s as \"Company\", mil.description as \"Milestone\", mil.milestone_at as \"Date\", mil.source_url as \"News Source\" from milestones as mil join     (select id     from objects     where entity_type='Company' and name=%s) as cid     on cid.id=mil.object_id order by mil.milestone_at desc limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
                else:
                    cur.execute("select %s as \"Company\", mil.description as \"Milestone\", mil.milestone_at as \"Date\", mil.source_url as \"News Source\" from milestones as mil join     (select id     from objects     where entity_type='Company' and name=%s) as cid     on cid.id=mil.object_id order by mil.milestone_at asc limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
            elif request.form['Query Type'] == "Acquired By":
                cur.execute("select table1.name as \"Company\", obj.name as \"Acquired By\", table1.price_amount as \"Amount\", table1.price_currency_code as \"Currency\",     table1.acquired_at as \"Deal Date\" from objects as obj join     (select acq.acquiring_object_id, cid.name, acq.price_amount, acq.price_currency_code, acq.acquired_at     from acquisitions as acq join         (select id,name         from objects         where entity_type = 'Company' and name=%s) as cid         on cid.id=acq.acquired_object_id     ) as table1 on table1.acquiring_object_id=obj.id order by obj.name desc; ", (request.form['Entity Name'],))
            elif request.form['Query Type'] == "Current Employees":
                if request.form['Sort By'] == "Ascending Order of Name":
                    cur.execute("select %s as \"Company\", concat(first_name, ' ', last_name) as \"Employee Name\", table1.title as \"Role\" from people join      (	select distinct person_object_id, title      from relationships as rel join         (select id         from objects         where entity_type='Company' and name=%s) as cid         on rel.relationship_object_id = cid.id and rel.is_past = 0)as table1 on table1.person_object_id = object_id order by first_name, last_name limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
                else:
                    cur.execute("select %s as \"Company\", concat(first_name, ' ', last_name) as \"Employee Name\", table1.title as \"Role\" from people join      (	select distinct person_object_id, title      from relationships as rel join         (select id         from objects         where entity_type='Company' and name=%s) as cid         on rel.relationship_object_id = cid.id and rel.is_past = 0)as table1 on table1.person_object_id = object_id order by first_name desc, last_name desc limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
            elif request.form['Query Type'] == "Offices":
                if request.form['Sort By'] == "Ascending Order of City":
                    cur.execute("select %s as \"Company\", region as \"Region\", address1 as \"Address\", city as \"City\", zip_code as \"Zip Code\", state_code as \"State\", country_code as \"Country\" from offices where object_id in (select id from objects where name = %s and entity_type = 'Company') order by city limit %s", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
                else:
                    cur.execute("select %s as \"Company\", region as \"Region\", address1 as \"Address\", city as \"City\", zip_code as \"Zip Code\", state_code as \"State\", country_code as \"Country\" from offices where object_id in (select id from objects where name = %s and entity_type = 'Company') order by city desc limit %s", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
            elif request.form['Query Type'] == "Products":
                if request.form['Sort By'] == "Ascending Order of Product Name":
                    cur.execute("select %s as \"Compnay\", name as \"Product\", status as \"Status\", domain as \"Domain\", homepage_url as \"Homepage URL\" from objects where parent_id in (select id from objects where name = %s and entity_type = 'Company') and entity_type = 'Product' order by name limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
                else:
                    cur.execute("select %s as \"Compnay\", name as \"Product\", status as \"Status\", domain as \"Domain\", homepage_url as \"Homepage URL\" from objects where parent_id in (select id from objects where name = %s and entity_type = 'Company') and entity_type = 'Product' desc order by name limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
            else:
                if request.form['Sort By'] == "Ascending Order of Name":
                    cur.execute("select %s as \"Company\", concat(first_name, ' ', last_name) as \"Employee Name\", table1.title as \"Role\", (case when table1.is_past = 0 then 'Current' else 'Former' end) as \"Employment Status\" from people join      (	select distinct person_object_id, title, is_past      from relationships as rel join         (select id         from objects         where entity_type='Company' and name=%s) as cid         on rel.relationship_object_id = cid.id)as table1 on table1.person_object_id = object_id order by first_name, last_name limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
                else:
                    cur.execute("select %s as \"Company\", concat(first_name, ' ', last_name) as \"Employee Name\", table1.title as \"Role\", (case when table1.is_past = 0 then 'Current' else 'Former' end) as \"Employment Status\" from people join      (	select distinct person_object_id, title, is_past      from relationships as rel join         (select id         from objects         where entity_type='Company' and name=%s) as cid         on rel.relationship_object_id = cid.id)as table1 on table1.person_object_id = object_id order by first_name desc, last_name desc limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
        elif request.form['Entity Type'] == "Person":
            if request.form['Query Type'] == "All Jobs":
                if request.form['Sort By'] == "Company Name Ascending":
                    cur.execute("select %s as \"Name\", o.name as \"Company\", r.title as \"Role\", (case when r.is_past=0 then 'Current' else 'Former' end) as \"Employment Status\" from relationships as r, objects as o where o.id = r.relationship_object_id and r.person_object_id = (select object_id from people where first_name = split_part(%s, ' ', 1) and last_name = split_part(%s, ' ', 2)) order by name asc limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
                else:
                    cur.execute("select %s as \"Name\", o.name as \"Company\", r.title as \"Role\", (case when r.is_past=0 then 'Current' else 'Former' end) as \"Employment Status\" from relationships as r, objects as o where o.id = r.relationship_object_id and r.person_object_id = (select object_id from people where first_name = split_part(%s, ' ', 1) and last_name = split_part(%s, ' ', 2)) order by name desc limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
            else:
                cur.execute("select %s as \"Name\", f.birthplace as \"Birthplace\", f.affliation_name as \"Current Affiliations\", d.degree_type as \"Educational Degree\", d.subject as \"Subjects\", d.institution as \"Institution\", d.graduated_at as \"Graduated On\" from degrees as d right join (select object_id, birthplace, affliation_name from people where object_id in (select object_id from people where first_name = split_part(%s, ' ', 1) and last_name = split_part(%s, ' ', 2))) as f on d.object_id = f.object_id;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entity Name']))
        elif request.form['Entity Type'] == "Product":
            if request.form['Query Type'] == "Creator Company":
                cur.execute("select %s as \"Product\", name as \"Creator Company\" from objects where entity_type = 'Company' and id in (select parent_id from objects where name =%s and entity_type = 'Product')", (request.form['Entity Name'], request.form['Entity Name']))
        elif request.form['Entity Type'] == "City":
            if request.form['Query Type'] == "All Offices Located in the City":
                if request.form["Sort By"] == "Company Name Ascending":
                    cur.execute("select o.city as \"City\", ob.name as \"Company\", o.address1 as \"Address\", o.region as \"Region\", o.zip_code as \"Zip Code\" from objects as ob, offices as o where ob.id = o.object_id and o.city = %s order by name limit %s;", (request.form['Entity Name'], request.form['Entries']))
                elif request.form["Sort By"] == "Company Name Descending":
                    cur.execute("select o.city as \"City\", ob.name as \"Company\", o.address1 as \"Address\", o.region as \"Region\", o.zip_code as \"Zip Code\" from objects as ob, offices as o where ob.id = o.object_id and o.city = %s order by name desc limit %s;", (request.form['Entity Name'], request.form['Entries']))
        elif request.form['Entity Type'] == "Institution":
            if request.form['Query Type'] == "Alumni Working in the industry":
                if request.form["Sort By"] == "Person Name Ascending":
                    cur.execute("select %s as \"Institution\", concat(p.first_name, ' ', p.last_name) as \"Person Name\" from people as p, (select distinct object_id from degrees where institution is not null and institution = %s) as foo where p.object_id = foo.object_id order by \"Person Name\" limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
                elif request.form["Sort By"] == "Person Name Descending":
                    cur.execute("select %s as \"Institution\", concat(p.first_name, ' ', p.last_name) as \"Person Name\" from people as p, (select distinct object_id from degrees where institution is not null and institution = %s) as foo where p.object_id = foo.object_id order by \"Person Name\" desc limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
        elif request.form['Entity Type'] == "Investor":
            if request.form['Query Type'] == "Investments":
                if request.form['Sort By'] == "Ascending order of Company Name":
                    cur.execute("select %s as \"Investor\", o.name as \"Invested in\", foo.funding_round_type as \"Funding Round\" from objects as o, (select f.funding_round_id, f.object_id, f.funding_round_type from funding_rounds as f, (select funding_round_id, funded_object_id from investments where investor_object_id in (select id from objects where name = %s and entity_type = 'FinancialOrg')) as foo where f.funding_round_id = foo.funding_round_id and f.object_id = foo.funded_object_id) as foo where o.id = foo.object_id order by \"Invested in\" limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
                else:
                    cur.execute("select %s as \"Investor\", o.name as \"Invested in\", foo.funding_round_type as \"Funding Round\" from objects as o, (select f.funding_round_id, f.object_id, f.funding_round_type from funding_rounds as f, (select funding_round_id, funded_object_id from investments where investor_object_id in (select id from objects where name = %s and entity_type = 'FinancialOrg')) as foo where f.funding_round_id = foo.funding_round_id and f.object_id = foo.funded_object_id) as foo where o.id = foo.object_id order by \"Invested in\" desc limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
            elif request.form['Query Type'] == "Companies in Portfolio":
                if request.form['Sort By'] == "Ascending order of Company Name":
                    cur.execute("select %s as Investor, o.name as \"Company Invested in\" from objects as o, (select distinct funded_object_id from investments where investor_object_id in (select id from objects where name = %s and entity_type = 'FinancialOrg')) as foo where o.id = foo.funded_object_id order by name asc limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
                else:
                    cur.execute("select %s as Investor, o.name as \"Company Invested in\" from objects as o, (select distinct funded_object_id from investments where investor_object_id in (select id from objects where name = %s and entity_type = 'FinancialOrg')) as foo where o.id = foo.funded_object_id order by name asc limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
            else:
                if request.form['Sort By'] == "Amount in a Fund Ascending":
                    cur.execute("select %s as \"Investment Firm\", name as \"Fund Name\", (case when raised_amount = 0.0 then 'N/A' else cast(raised_amount as text) end) as \"Fund Amount\", raised_currency_code as \"Currency\", funded_at as \"Fund Creation Date\", source_url as \"News Source\" from funds where object_id in (select id from objects where name = %s and entity_type = 'FinancialOrg') order by raised_amount limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
                elif request.form['Sort By'] == "Amount in a Fund Descending":
                    cur.execute("select %s as \"Investment Firm\", name as \"Fund Name\", (case when raised_amount = 0.0 then 'N/A' else cast(raised_amount as text) end) as \"Fund Amount\", raised_currency_code as \"Currency\", funded_at as \"Fund Creation Date\", source_url as \"News Source\" from funds where object_id in (select id from objects where name = %s and entity_type = 'FinancialOrg') order by raised_amount desc limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
                elif request.form['Sort By'] == "Most Recent Fund":
                    cur.execute("select %s as \"Investment Firm\", name as \"Fund Name\", (case when raised_amount = 0.0 then 'N/A' else cast(raised_amount as text) end) as \"Fund Amount\", raised_currency_code as \"Currency\", funded_at as \"Fund Creation Date\", source_url as \"News Source\" from funds where object_id in (select id from objects where name = %s and entity_type = 'FinancialOrg') order by funded_at desc limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))
                else:
                    cur.execute("select %s as \"Investment Firm\", name as \"Fund Name\", (case when raised_amount = 0.0 then 'N/A' else cast(raised_amount as text) end) as \"Fund Amount\", raised_currency_code as \"Currency\", funded_at as \"Fund Creation Date\", source_url as \"News Source\" from funds where object_id in (select id from objects where name = %s and entity_type = 'FinancialOrg') order by funded_at limit %s;", (request.form['Entity Name'], request.form['Entity Name'], request.form['Entries']))

        formdata = cur.fetchall()
        heading = cur.description
        return render_template('data.html', headings = heading, form_data = formdata)


@app.route("/query2")
def query2():
    return render_template('query2.html')

@app.route("/data2", methods = ['POST', 'GET'])
def data2():
    if request.method == 'GET':
        return f"The URL /data2 is accessed directly. Try going to '/query2' to submit form"
    # conn = psycopg2.connect(dbname="startup_project", user="postgres", password="jatin", host="localhost", port="5432")
    conn = psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if request.method == 'POST':
        
        if request.form['Entity Relationship'] == "Company-Investor":
            if request.form['Query Type'] == "All Transactions between them":
                if request.form['Sort By'] == "Least Recent Transaction":
                    cur.execute("select %s as \"Company\", %s as \"Investor\", f.funding_round_type as \"Funding Round\", f.funded_at as \"Funding Date\" from funding_rounds as f, (select funding_round_id, funded_object_id, investor_object_id from investments where funded_object_id in (select id from objects where name = %s and entity_type = 'Company') and investor_object_id in (select id from objects where name = %s and entity_type = 'FinancialOrg')) as foo where f.object_id = foo.funded_object_id and f.funding_round_id = foo.funding_round_id order by funded_at asc limit %s;", (request.form['Entity One'], request.form['Entity Two'], request.form['Entity One'], request.form['Entity Two'], request.form['Entries']))
                elif request.form['Sort By'] == "Most Recent Transaction":
                    cur.execute("select %s as \"Company\", %s as \"Investor\", f.funding_round_type as \"Funding Round\", f.funded_at as \"Funding Date\" from funding_rounds as f, (select funding_round_id, funded_object_id, investor_object_id from investments where funded_object_id in (select id from objects where name = %s and entity_type = 'Company') and investor_object_id in (select id from objects where name = %s and entity_type = 'FinancialOrg')) as foo where f.object_id = foo.funded_object_id and f.funding_round_id = foo.funding_round_id order by funded_at desc limit %s;", (request.form['Entity One'], request.form['Entity Two'], request.form['Entity One'], request.form['Entity Two'], request.form['Entries']))
        elif request.form['Entity Relationship'] == "Person-Company":
             if request.form['Query Type'] == "All positions held by person in the company":
                     cur.execute("select %s as \"Name\", %s as \"Company\", r.title as \"Role\", (case when r.is_past=0 then 'Current' else 'Former' end) as \"Employment Status\" from relationships as r, objects as o where o.id = r.relationship_object_id and r.person_object_id = (select object_id from people where first_name = split_part(%s, ' ', 1) and last_name = split_part(%s, ' ', 2)) and r.relationship_object_id in (select id from objects where name = %s) order by r.is_past limit %s;", (request.form['Entity One'], request.form['Entity Two'], request.form['Entity One'], request.form['Entity One'], request.form['Entity Two'], request.form['Entries']))

        formdata = cur.fetchall()
        heading = cur.description
        return render_template('data.html', headings = heading, form_data = formdata)


@app.route("/query3")
def query3():
    return render_template('query3.html')

@app.route("/data3", methods = ['POST', 'GET'])
def data3():
    if request.method == 'GET':
        return f"The URL /data2 is accessed directly. Try going to '/query2' to submit form"
    # conn = psycopg2.connect(dbname="startup_project", user="postgres", password="jatin", host="localhost", port="5432")
    conn = psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if request.method == 'POST':
        
        if request.form['Entity Relationship'] == "Companies with the Most Acquisitions":
            cur.execute("select o.name as \"Company\", foo.count as \"Number of Acquisitions\" from objects as o, (select acquiring_object_id, count(acquired_object_id) from acquisitions group by acquiring_object_id) as foo where o.id = foo.acquiring_object_id order by foo.count desc limit %s;", (request.form['Entries'],))
        elif request.form['Entity Relationship'] == "Companies with the Most Funding Raised":
            cur.execute("select o.name as \"Company\", foo.sum as \"Total Funds Raised (in USD)\" from objects as o, (select object_id, sum(raised_amount_usd) from funding_rounds group by object_id) as foo where foo.object_id = o.id order by foo.sum desc limit %s;", (request.form['Entries'],))
        elif request.form['Entity Relationship'] == "Companies with the Most products launched":
            cur.execute("select o.name as \"Company\", foo.count as \"Products Launched\" from objects as o, (select parent_id, count(id) from objects where entity_type = 'Product' group by parent_id) as foo where foo.parent_id = o.id order by foo.count desc limit %s;", (request.form['Entries'],))
        elif request.form['Entity Relationship'] == "Companies employing the Most number of People":
            cur.execute("select o.name as \"Company\", foo.count as \"Number of Current Employees\" from objects as o, (select relationship_object_id, count(person_object_id) from relationships where is_past = 0 group by relationship_object_id) as foo where foo.relationship_object_id = o.id order by foo.count desc limit %s;", (request.form['Entries'],))
        elif request.form['Entity Relationship'] == "Companies with the Most Offices":
            cur.execute("select o.name as \"Company\", foo.count as \"Number of Offices\" from objects as o, (select object_id, count(office_id) from offices group by object_id) as foo where foo.object_id = o.id order by foo.count desc limit %s;", (request.form['Entries'],))
        elif request.form['Entity Relationship'] == "Investors with the Most Available Funds":
            cur.execute("select o.name as \"Investment Firm\", foo.sum as \"Total Funds Available (in USD)\" from objects as o, (select object_id, sum(raised_amount) from funds group by object_id) as foo where foo.object_id = o.id order by foo.sum desc limit %s;", (request.form['Entries'],))
        elif request.form['Entity Relationship'] == "Investors with the Most number of Companies in Portfolio":
            cur.execute("select o.name as \"Investment Firm\", foo.count as \"Total Companies in Portfolio\" from objects as o, (select investor_object_id, count(distinct funded_object_id) from investments group by investor_object_id) as foo where foo.investor_object_id = o.id order by foo.count desc limit %s;", (request.form['Entries'],))
        elif request.form['Entity Relationship'] == "People who have worked the Most Jobs":
            cur.execute("select o.name as \"Person Name\", foo.count as \"Total Jobs Worked\" from objects as o, (select person_object_id, count(relationship_object_id) from relationships group by person_object_id) as foo where foo.person_object_id = o.id order by foo.count desc limit %s;", (request.form['Entries'],))
        elif request.form['Entity Relationship'] == "City with Most Number of Offices":
            cur.execute("select city as \"City\", count(*) as \"Number of Offices in the City\" from offices where city is not null group by city order by \"Number of Offices in the City\" desc limit %s;", (request.form['Entries'],))
        elif request.form['Entity Relationship'] == "Institution with Most number of People Working in Companies":
            cur.execute("select institution as \"Institution\", count(*) as \"Number of People Working in Startups\" from degrees where institution is not null group by institution order by \"Number of People Working in Startups\" desc limit %s;", (request.form['Entries'],))

        formdata = cur.fetchall()
        heading = cur.description
        return render_template('data.html', headings = heading, form_data = formdata)

@app.route("/update")
def update():
    return render_template('update.html')

@app.route("/update-next", methods = ['POST', 'GET'])
def update_next():
    if request.method == 'GET':
        return f"The URL /update-next is accessed directly. Try going to '/update' to submit form"
    if request.method == 'POST':
        if request.form['Entity Type'] == 'Company':
            if request.form['Query Type'] == 'Name':
                return render_template('update/update_company_name.html')
        elif request.form['Entity Type'] == 'Investor':
            if request.form['Query Type'] == 'Name':
                return render_template('update/update_investor_name.html')
        elif request.form['Entity Type'] == 'Person':
            if request.form['Query Type'] == 'Name':
                return render_template('update/update_person_name.html')
        elif request.form['Entity Type'] == 'Product':
            if request.form['Query Type'] == 'Name':
                return render_template('update/update_product_name.html')
            elif request.form['Query Type'] == 'Creator Company':
                return render_template('update/update_product_company.html')

@app.route("/update-submit", methods = ['POST', 'GET'])
def update_submit():
    if request.method == 'GET':
        return f"The URL /update-submit is accessed directly. Try going to '/update' to submit form"
    if request.method == 'POST':
        # conn = psycopg2.connect(dbname="startup_project", user="postgres", password="jatin", host="localhost", port="5432")
        conn = psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        if request.form['Entity Type'] == 'Company-Name':
            try:
                cur.execute("update objects set name = %s where name = %s and entity_type = 'Company';", (request.form['Updated'], request.form['Previous']))
                conn.commit()
                return render_template('update/update_success.html')
            except:
                conn.rollback()
                return render_template('update/update_fail.html')
        elif request.form['Entity Type'] == 'Investor-Name':
            try:
                cur.execute("update objects set name = %s where name = %s and entity_type = 'FinancialOrg';", (request.form['Updated'], request.form['Previous']))
                conn.commit()
                return render_template('update/update_success.html')
            except:
                conn.rollback()
                return render_template('update/update_fail.html')
        elif request.form['Entity Type'] == 'Person-Name':
            try:
                cur.execute("update objects set name = %s where name = %s and entity_type = 'Person';", (request.form['Updated'], request.form['Previous']))
                cur.execute("update people set first_name = split_part(%s, ' ', 1), last_name = split_part(%s, ' ', 2) where first_name = split_part(%s, ' ', 1) and last_name = split_part(%s, ' ', 2);", (request.form['Updated'], request.form['Updated'], request.form['Previous'], request.form['Previous']))
                conn.commit()
                return render_template('update/update_success.html')
            except:
                conn.rollback()
                return render_template('update/update_fail.html')
        elif request.form['Entity Type'] == 'Product-Name':
            try:
                cur.execute("update objects set name = %s where name = %s and entity_type = 'Product';", (request.form['Updated'], request.form['Previous']))
                conn.commit()
                return render_template('update/update_success.html')
            except:
                conn.rollback()
                return render_template('update/update_fail.html')
        elif request.form['Entity Type'] == 'Product-Company':
            try:
                cur.execute("update objects set parent_id = (select id from objects where name = %s and entity_type = 'Company') where name = %s and parent_id = (select id from objects where name = %s and entity_type = 'Company');", (request.form['Updated Creator Company'], request.form['Product Name'], request.form['Current Creator Company']))
                conn.commit()
                return render_template('update/update_success.html')
            except:
                conn.rollback()
                return render_template('update/update_fail.html')
            
@app.route("/insert")
def add():
    return render_template('add.html')

@app.route("/insert-next", methods = ['POST', 'GET'])
def add_next():
    if request.method == 'GET':
        return f"The URL /insert-next is accessed directly. Try going to '/insert' to submit form"
    if request.method == 'POST':
        if request.form['Entity Type'] == 'Company':
            if request.form['Query Type'] == 'New Company':
                return render_template('add/new_company.html')
            elif request.form['Query Type'] == 'New Acquisition':
                return render_template('add/new_acquisition.html')
            elif request.form['Query Type'] == 'New Milestone':
                return render_template('add/new_milestone.html')
            elif request.form['Query Type'] == 'New Office':
                return render_template('add/new_office.html')
            elif request.form['Query Type'] == 'New Product':
                return render_template('add/new_product.html')
            elif request.form['Query Type'] == 'IPO':
                return render_template('add/new_ipo.html')
            elif request.form['Query Type'] == 'New Funding':
                return render_template('add/new_funding.html')
        elif request.form['Entity Type'] == 'Investor':
            if request.form['Query Type'] == 'New Investor':
                return render_template('add/new_investor.html')
            elif request.form['Query Type'] == 'New Fund':
                return render_template('add/new_fund.html')
            elif request.form['Query Type'] == 'New Investment':
                return render_template('add/new_investment.html')
        elif request.form['Entity Type'] == 'Person':
            if request.form['Query Type'] == 'New Person':
                return render_template('add/new_person.html')
            elif request.form['Query Type'] == 'New Job':
                return render_template('add/new_job.html')


@app.route("/insert-submit", methods = ['POST', 'GET'])
def add_submit():
    if request.method == 'GET':
        return f"The URL /insert-submit is accessed directly. Try going to '/insert' to submit form"
    if request.method == 'POST':
        # conn = psycopg2.connect(dbname="startup_project", user="postgres", password="jatin", host="localhost", port="5432")
        conn = psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        global a_id
        global d_id
        global fr_id
        global f_id
        global i_id
        global ipo_id
        global m_id
        global o_id
        global of_id
        global p_id
        global r_id
        if request.form['Entity Type'] == 'New Company':
            try:              
                cur.execute("insert into objects (id, entity_type, entity_id, name, permalink, homepage_url) values (%s, 'Company', %s, %s, concat('/company/', %s), %s);", (o_id, o_id, request.form['Name'], request.form['Name'], request.form['url']))
                conn.commit()
                o_id = o_id + 1
                return render_template('add/success.html')
            except:
                conn.rollback()
                return render_template('add/fail.html')
        elif request.form['Entity Type'] == 'New Investor':
            try:
                cur.execute("insert into objects (id, entity_type, entity_id, name, permalink, homepage_url) values (%s, 'FinancialOrg', %s, %s, concat('/financial-organization/', %s), %s);", (o_id, o_id, request.form['Name'], request.form['Name'], request.form['url']))
                conn.commit()
                o_id = o_id + 1
                return render_template('add/success.html')
            except:
                conn.rollback()
                return render_template('add/fail.html')
        elif request.form['Entity Type'] == 'New Person':
            try:
                cur.execute("insert into objects (id, entity_type, entity_id, name, permalink) values (%s, 'Person', %s, %s, concat('/person/', %s));", (o_id, o_id, request.form['Name'], request.form['Name']))
                cur.execute("insert into people (id, object_id, first_name, last_name, birthplace, affliation_name) values (%s, %s, split_part(%s, ' ', 1), split_part(%s, ' ', 2), %s, %s);", (p_id, o_id, request.form['Name'], request.form['Name'], request.form['birth'], request.form['aff']))
                cur.execute("insert into degrees (id, object_id, degree_type, subject, institution) values (%s, %s, %s, %s, %s);", (d_id, o_id, request.form['degree'], request.form['subjects'], request.form['institute']))
                conn.commit()
                o_id = o_id + 1
                p_id = p_id + 1
                d_id = d_id + 1
                return render_template('add/success.html')
            except:
                conn.rollback()
                return render_template('add/fail.html')
        elif request.form['Entity Type'] == 'New Job':
            try:
                cur.execute("insert into relationships(id, relationship_id, person_object_id, relationship_object_id, is_past, title) values (%s, %s, (select id from objects where name = %s and entity_type = 'Person'), (select id from objects where name = %s and entity_type = 'Company'), 0, %s)", (r_id, r_id, request.form['Name'], request.form['company'], request.form['role']))
                conn.commit()
                r_id = r_id + 1
                return render_template('add/success.html')
            except:
                conn.rollback()
                return render_template('add/fail.html')
        elif request.form['Entity Type'] == 'New Fund':
            try:
                cur.execute("insert into funds(id, fund_id, object_id, name, raised_amount, raised_currency_code, source_url) values (%s, %s, (select id from objects where name = %s and entity_type = 'FinancialOrg'), %s, %s, %s, %s)", (f_id, f_id, request.form['Name'], request.form['fund'], request.form['amount'], request.form['currency'], request.form['source']))
                conn.commit()
                f_id = f_id + 1
                return render_template('add/success.html')
            except:
                conn.rollback()
                return render_template('add/fail.html')
        elif request.form['Entity Type'] == 'New Acquisition':
            try:
                cur.execute("insert into acquisitions(id, acquisition_id, acquiring_object_id, acquired_object_id, price_amount, price_currency_code, source_url) values (%s, %s, (select id from objects where name = %s and entity_type = 'Company'), (select id from objects where name = %s and entity_type = 'Company'), %s, %s, %s)", (a_id, a_id, request.form['acquiring'], request.form['acquired'], request.form['amount'], request.form['currency'], request.form['source']))
                conn.commit()
                a_id = a_id + 1
                return render_template('add/success.html')
            except:
                conn.rollback()
                return render_template('add/fail.html')
        elif request.form['Entity Type'] == 'New Milestone':
            try:
                cur.execute("insert into milestones(id, object_id, milestone_at, description, source_url) values (%s, (select id from objects where name = %s and entity_type = 'Company'), %s, %s, %s)", (m_id, request.form['Name'], request.form['date'], request.form['description'], request.form['source']))
                conn.commit()
                m_id = m_id + 1
                return render_template('add/success.html')
            except:
                conn.rollback()
                return render_template('add/fail.html')
        elif request.form['Entity Type'] == 'New Office':
            try:
                cur.execute("insert into offices(id, object_id, office_id, region, address1, city, zip_code, state_code) values (%s, (select id from objects where name = %s and entity_type = 'Company'), %s, %s, %s, %s, %s, %s)", (of_id, request.form['Name'], of_id, request.form['region'], request.form['address'], request.form['city'], request.form['zip'], request.form['state']))
                conn.commit()
                of_id = of_id + 1
                return render_template('add/success.html')
            except:
                conn.rollback()
                return render_template('add/fail.html')
        elif request.form['Entity Type'] == 'New Product':
            try:
                cur.execute("insert into objects (id, entity_type, entity_id, parent_id, name, permalink) values (%s, 'Product', %s, (select id from objects where name = %s and entity_type = 'Company'), %s, concat('/product/', %s));", (o_id, o_id, request.form['parent'], request.form['Name'], request.form['Name']))
                conn.commit()
                o_id = o_id + 1
                return render_template('add/success.html')
            except:
                conn.rollback()
                return render_template('add/fail.html')
        elif request.form['Entity Type'] == 'IPO':
            try:
                cur.execute("insert into ipos (id, ipo_id, object_id, valuation_amount, valuation_currecny_code, raised_amount, raised_currency_code, public_at, stock_symbol, source_url) values (%s, %s, (select id from objects where name = %s and entity_type = 'Company'), %s, %s, %s, %s, %s, %s, %s);", (ipo_id, ipo_id, request.form['Name'], request.form['valuation'], request.form['currency'], request.form['raised'], request.form['currency'], request.form['date'], request.form['symbol'], request.form['source']))
                conn.commit()
                ipo_id = ipo_id + 1
                return render_template('add/success.html')
            except:
                conn.rollback()
                return render_template('add/fail.html')
        elif request.form['Entity Type'] == 'New Funding':
            try:
                cur.execute("insert into funding_rounds (id, funding_round_id, object_id, funded_at, funding_round_type, raised_amount_usd) values (%s, %s, (select id from objects where name = %s and entity_type = 'Company'), %s, %s, %s);", (fr_id, request.form['code'], request.form['Name'], request.form['date'], request.form['round'], request.form['raised']))
                conn.commit()
                fr_id = fr_id + 1
                return render_template('add/success.html')
            except:
                conn.rollback()
                return render_template('add/fail.html')
        elif request.form['Entity Type'] == 'New Investment':
            try:
                cur.execute("insert into investments (id, funding_round_id, funded_object_id, investor_object_id) values (%s, %s, (select id from objects where name = %s and entity_type = 'Company'), (select id from objects where name = %s and entity_type = 'FinancialOrg'));", (i_id, request.form['code'], request.form['company'], request.form['Name']))
                conn.commit()
                i_id = i_id + 1
                return render_template('add/success.html')
            except:
                conn.rollback()
                return render_template('add/fail.html')

@app.route("/delete")
def delete():
    return render_template('delete.html')

@app.route("/delete-next", methods = ['POST', 'GET'])
def delete_next():
    if request.method == 'GET':
        return f"The URL /delete-next is accessed directly. Try going to '/delete' to submit form"
    if request.method == 'POST':
        if request.form['Entity Type'] == 'Company':
            if request.form['Query Type'] == 'All Company Records':
                return render_template('delete/all_company.html')
        elif request.form['Entity Type'] == 'Investor':
            if request.form['Query Type'] == 'All Investor Records':
                return render_template('delete/all_investor.html')
        elif request.form['Entity Type'] == 'Person':
            if request.form['Query Type'] == 'All Person Records':
                return render_template('delete/all_person.html')

@app.route("/delete-submit", methods = ['POST', 'GET'])
def delete_submit():
    if request.method == 'GET':
        return f"The URL /insert-submit is accessed directly. Try going to '/insert' to submit form"
    if request.method == 'POST':
        # conn = psycopg2.connect(dbname="startup_project", user="postgres", password="jatin", host="localhost", port="5432")
        conn = psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        if request.form['Entity Type'] == 'All Company Records':
            try:              
                cur.execute("delete from acquisitions where acquiring_object_id in (select id from objects where name = %s and entity_type = 'Company') or acquired_object_id in (select id from objects where name = %s and entity_type = 'Company');", (request.form['Name'], request.form['Name']))
                cur.execute("delete from funding_rounds where object_id in (select id from objects where name = %s and entity_type = 'Company');", (request.form['Name'],))                
                cur.execute("delete from investments where funded_object_id in (select id from objects where name = %s and entity_type = 'Company');", (request.form['Name'],))
                cur.execute("delete from ipos where object_id in (select id from objects where name = %s and entity_type = 'Company');", (request.form['Name'],))
                cur.execute("delete from milestones where object_id in (select id from objects where name = %s and entity_type = 'Company');", (request.form['Name'],))
                cur.execute("delete from offices where object_id in (select id from objects where name = %s and entity_type = 'Company');", (request.form['Name'],))
                cur.execute("delete from relationships where person_object_id in (select id from objects where name = %s and entity_type = 'Company');", (request.form['Name'],))
                cur.execute("delete from people where affliation_name = %s", (request.form['Name'],))
                cur.execute("delete from objects where name = %s and entity_type = 'Company';", (request.form['Name'],))
                conn.commit()
                return render_template('delete/success.html')
            except:
                conn.rollback()
                return render_template('delete/fail.html')
        elif request.form['Entity Type'] == 'All Investor Records':
            try:
                cur.execute("delete from funds where object_id in (select id from objects where name = %s and entity_type = 'FinancialOrg')", (request.form['Name'],))
                cur.execute("delete from investments where investor_object_id in (select id from objects where name = %s and entity_type = 'FinancialOrg')", (request.form['Name'],))
                cur.execute("delete from objects where name = %s and entity_type = 'FinancialOrg'", (request.form['Name'],))
                conn.commit()
                return render_template('delete/success.html')
            except:
                conn.rollback()
                return render_template('delete/fail.html')
        elif request.form['Entity Type'] == 'All Person Records':
            try:
                cur.execute("delete from degrees where object_id in (select id from objects where name = %s and entity_type = 'Person')", (request.form['Name'],))
                cur.execute("delete from people where object_id in (select id from objects where name = %s and entity_type = 'Person')", (request.form['Name'],))
                cur.execute("delete from relationships where person_object_id in (select id from objects where name = %s and entity_type = 'Person')", (request.form['Name'],))
                cur.execute("delete from objects where name = %s and entity_type = 'Person'", (request.form['Name'],))
                conn.commit()
                return render_template('delete/success.html')
            except:
                conn.rollback()
                return render_template('delete/fail.html')

app.run(port=5036)