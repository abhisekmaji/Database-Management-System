#!/bin/bash
#setup dependencies for front end

pip3 install flask
pip3 install psycopg2
